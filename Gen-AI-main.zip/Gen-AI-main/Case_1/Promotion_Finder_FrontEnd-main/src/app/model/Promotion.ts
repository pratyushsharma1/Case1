export interface Promotion {
  id: number;
  promotionName: string;
  termsOfUse: string[];
  locations: string[];
}
