export const environment = {
  production: false,
  promotionApiUrl: 'http://localhost:8080/promotions',  // Spring Boot API endpoint
  locationApiUrl: 'http://localhost:8080', // API for countries, etc.
};

