package com.backend.promotionfinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PromotionfinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(PromotionfinderApplication.class, args);
	}

}
