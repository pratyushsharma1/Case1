package com.backend.promotionfinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PromotionfinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
